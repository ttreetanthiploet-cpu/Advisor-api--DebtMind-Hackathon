from app.services.functions.AmortiseCal import findInstallment, findTerm, findInterestPaid
from app.services.model import DebtSolnSummary, DebtSolnAcc
from app.services.HTML.model_HTML import OfferCard, OfferCardAcc
import datetime as dt
import pandas as pd

def create_nonTDR_offer_card(planId: str,
                             currentStatus: dict[str, any],
                             dfOffer) -> OfferCard:

    old_installment = currentStatus["CurrentInstallment"]
    old_totalIntPaid = currentStatus["expIntTotal"]

    new_installment = dfOffer["installment"].sum()
    new_total_int = dfOffer["expIntTotal"].sum()

    METAINFO = [
            {
                "METATYPE": "OLD",
                "DESC": "ระยะเวลาผ่อนชำระจากอัตราผ่อนชำระเดิม",
                "PREVALUE": f"{currentStatus["actualTerm"]} งวด",
                "NEWVALUE": "",
            },
            {
                "METATYPE": "NEW",
                "DESC": "ระยะเวลาผ่อนชำระจากอัตราผ่อนชำระใหม่",
                "PREVALUE": "",
                "NEWVALUE": f"{currentStatus["remainTerm"]} งวด",
            },
            {
                "METATYPE": "OLD",
                "DESC": "ดอกเบี้ยรวมตลอดสัญญา",
                "PREVALUE": f"{old_totalIntPaid:,.2f} → {new_total_int:,.2f} บาท",
                "NEWVALUE": "",
            },
        ]

    offer_card_dict = {
        # -----------------------
        # HEADER
        # -----------------------
        "ICONLINK": "https://cdn-icons-png.flaticon.com/512/3135/3135706.png",
        "OFFERLINK": "PLACEHOLDER_OFFERLINK",
        "PLANID": planId,
        "PLANDESC": "มาตรการลดค่างวดตามสัญญาคงเหลือ",
        "ACCOUNTS": ",".join(sorted(list(dfOffer["accNo"]))),
        "OS": f"{currentStatus["TotalOS"]:,.2f}",
        "IFSTEP": "",
        "PREVINSTALLMENT": f"{old_installment:,.0f}",
        "NEWINSTALLMENT": f"{new_installment:,.0f}",
        "CNT_ELIGIBLE_ACC": f"{len(dfOffer[dfOffer["fg_eligible"]])}",
        # -----------------------
        # META INFO
        # -----------------------
        "METAINFO": METAINFO
        
    }

    return OfferCard(**offer_card_dict)

def create_nTDRoffer_cardAcc(solutionAcc: dict[str, any],
                         originalAcc: dict[str, any],
                         fgEligible: bool)-> OfferCardAcc:
    metainfo = []
    metainfo.append({"METATYPE": "OLD",
                        "DESC": "ระยะเวลาผ่อนชำระตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc.get("term")} งวด",
                        "NEWVALUE": ""})
    
    if fgEligible:
        metainfo.append({"METATYPE": "CHANGE",
                        "DESC": "ดอกเบี้ยรวมตลอดสัญญา",
                        "PREVALUE": f"{originalAcc["expIntTotal"]:,.2f}",
                        "NEWVALUE": f"{solutionAcc["expIntTotal"]:,.2f} บาท"})
    else:
        metainfo.append({"METATYPE": "OLD",
                        "DESC": "ค่างวดผ่อนชำระตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc["installment"]:,.0f} บาท/งวด",
                        "NEWVALUE": ""})
        metainfo.append({"METATYPE": "OLD",
                        "DESC": "ดอกเบี้ยรวมตลอดสัญญาตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc["expIntTotal"]:,.2f} บาท",
                        "NEWVALUE": ""})
        
    offer_card_dict = {"ACC_NO": solutionAcc.get("refAccNo", ""),
                       "ACC_NAME": originalAcc.get("port", ""),
                       "OS": f"{solutionAcc.get("os", ""):,.2f}",
                       "INTRATE": f"{100*solutionAcc.get("intRate", ""):,.2f}",
                       "METAINFO": metainfo,
                       "ACC_NOTE": "" if fgEligible else "บัญชีนี้ไม่เข้าเกณฑ์เข้าร่วมมาตรการ จึงคงเงื่อนไขการชำระตามเดิม"}
    return OfferCardAcc(**offer_card_dict)

def product_nonTDR_Extsummary(planId: str,
                              currentStatus: dict[str, any],
                              dfAccConsult: pd.DataFrame,
                              dfOffer : pd.DataFrame,
                              solutionDesc : str)->DebtSolnSummary:
    plan = "NTDREXT"

    dfOfferAcc = dfOffer[dfOffer["fg_eligible"]][["accNo", "os", "installment", "intRate","remainTerm", "expIntTotal"]].copy()
    dfOfferAcc.rename(columns = {"accNo": "refAccNo",
                                 "installment": "installment",
                                 "remainTerm": "term",
                                 "intRate": "intRate"}, inplace = True)
    dfOfferAcc["plan"] = plan
    dfOfferAcc["planId"] = planId

    old_installment = currentStatus["CurrentInstallment"]
    old_totalIntPaid = currentStatus["expIntTotal"]
    
    description = (f"ข้อเสนอ {planId}: มาตรการลดอัตราการผ่อนชำระตามสัญญาคงเหลือ \n"
                   f"บัญชีที่พิจารณา: {",".join(sorted(list(dfOffer["accNo"])))} \n"
                   f"บัญชีที่สามารถพิจารณาลดอัตราการผ่อนชำระได้: {",".join(sorted(list(dfOffer[dfOffer["fg_eligible"]]["accNo"])))} \n"
                   f"โดยอัตราการผ่อนชำระรวมของบัญชีที่พิจารณาจะปรับลดลงจาก {old_installment:,.2f} บาท/งวด เป็น {dfOffer["installment"].sum():,.2f} บาท/งวด \n"
                   f"ดอกเบี้ยรวมตลอดสัญญามีการเปลี่ยนแปลงจากประมาณ {old_totalIntPaid:,.2f} บาท เป็นประมาณ {dfOffer["expIntTotal"].sum():,.2f} บาท \n")
    
    nTDROfferCard = create_nonTDR_offer_card(planId = planId,
                                             currentStatus = currentStatus,
                                             dfOffer = dfOffer)
    solutionAccList = [DebtSolnAcc(**offerAcc).model_dump() for offerAcc in dfOfferAcc.to_dict(orient="records")]
    dfAccConsultTmp = dfAccConsult.rename(columns = {"accNo": "refAccNo",
                                                     "remainTerm": "term"})
    originalAccList = dfAccConsultTmp.to_dict(orient="records")
    solution_lookup = {acc["refAccNo"]: acc for acc in solutionAccList}
    for ori_acc in originalAccList:
        if ori_acc["refAccNo"] in solution_lookup.keys():
            nTDROfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_nTDRoffer_cardAcc(solutionAcc = solution_lookup[ori_acc["refAccNo"]],
                                                                                    originalAcc = ori_acc,
                                                                                    fgEligible = True))
        else:
            nTDROfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_nTDRoffer_cardAcc(solutionAcc = ori_acc,
                                                                                    originalAcc = ori_acc,
                                                                                    fgEligible = False))

    nTDR_summary = DebtSolnSummary(**{"solutionDesc": solutionDesc,
                                        "plan": plan,
                                        "refAccNo": ",".join(sorted(list(dfOffer["accNo"]))),
                                        "planId": planId,
                                        "planDesc": "ลดค่างวดตามสัญญาคงเหลือ",
                                        "installment": dfOffer["installment"].sum(), #รายการผ่อนชำระงวดแรก
                                        "term": dfOffer["installment"].max(),
                                        "totalIntPaid": dfOffer["expIntTotal"].sum(),
                                        "constantPayment": False,
                                        "offerText": description,
                                        "offerCard": nTDROfferCard.model_dump(),
                                        "solnAcc": solutionAccList})
    return nTDR_summary

def generate_nonTDR_extension_offer(currentStatus: dict[str, any],
                                    dfAccConsult: pd.DataFrame)-> list[DebtSolnSummary]:
    
    nonTDR_summary_lst = []

    #### Find minimal solution that the bank can offer

    planId = "NTDREXT01" + dt.datetime.now().strftime("%Y%m%d%H%M%S") 

    # Create actualTerm column
    dfAccConsult["actualTerm"] = dfAccConsult.apply( lambda row: findTerm(totalOS=row["os"],
                                                                          annual_int=row["intRate"],
                                                                          monthly_payment=row["installment"]), axis=1)
    
    dfEligibleAcc = dfAccConsult[dfAccConsult["actualTerm"]<dfAccConsult["remainTerm"]]
    dfnonEligibleAcc = dfAccConsult[dfAccConsult["actualTerm"]>=dfAccConsult["remainTerm"]]
    dfnonEligibleAcc["fg_eligible"] = False
    dfnonEligibleAcc["expIntTotal"] = dfnonEligibleAcc.apply(lambda row: findInterestPaid(Outstanding=row["os"],
                                                                                          period_int=row["intRate"] / 12,
                                                                                          first_period_payment=row["installment"],
                                                                                          payment_period=row["actualTerm"]),  axis=1 )

    if len(dfEligibleAcc)>0:
        req_cols = ["accNo", "currentDPD", "os", "accruedInt", "intRate", "remainTerm", "expIntTotal"]
        dfEligibleAcc = dfEligibleAcc[req_cols].copy()
        dfEligibleAcc["installment"] = dfEligibleAcc.apply( lambda row: findInstallment(totalOS=row["os"],
                                                                                        annual_int=row["intRate"],
                                                                                        terms=row["remainTerm"]), axis=1)
        dfEligibleAcc["fg_eligible"] = True
        dfEligibleAcc["expIntTotal"] = dfEligibleAcc.apply(lambda row: findInterestPaid(Outstanding=row["os"],
                                                                                        period_int=row["intRate"] / 12,
                                                                                        first_period_payment=row["installment"],
                                                                                        payment_period=row["remainTerm"]),  axis=1 )

        dfnonTDRoffer = pd.concat([dfEligibleAcc, dfnonEligibleAcc[req_cols + ["installment", "fg_eligible"]]])
        

        Best_summary = product_nonTDR_Extsummary(planId=planId,
                                                 currentStatus = currentStatus,
                                                 dfAccConsult = dfAccConsult,
                                                 dfOffer = dfnonTDRoffer,
                                                 solutionDesc = "ลดค่างวดตามสัญญาคงเหลือ")

        nonTDR_summary_lst.append(Best_summary)

    return nonTDR_summary_lst
