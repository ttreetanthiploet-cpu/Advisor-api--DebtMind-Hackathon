import pandas as pd
from app.services.ai_agent.config import PL_MOU_interest_map
from app.services.functions.AmortiseCal import findInstallment, findTerm, findInterestPaid
from app.services.functions.util import DSR_feasibility, DSR_feasibile_payment
from app.services.model import DebtSolnSummary, DebtSolnAcc
from app.services.HTML.model_HTML import OfferCard, OfferCardAcc
import datetime as dt
import numpy as np

def create_plmou_offer_card(
    planId: str,
    accNoConcat: str,
    occ: str,
    solutionDesc: str,
    interest: float,
    installment: float,
    totalIntPaid: float,
    term: int,
    currentStatus: dict[str, any],
) -> OfferCard:

    old_installment = currentStatus["CurrentInstallment"]
    old_term = currentStatus["remainTerm"]
    old_totalIntPaid = currentStatus["expIntTotal"]

    offer_card_dict = {"ICONLINK": "https://cdn-icons-png.flaticon.com/512/3135/3135706.png",
                       "OFFERLINK": "PLACEHOLDER_OFFERLINK",
                       "PLANID": planId,
                       "OS": f"{currentStatus["TotalOS"]:,.2f}",
                       "PLANDESC": "รวมหนี้ผ่านสินเชื่อ MOU แบบไม่มีหลักประกัน",
                       "ACCOUNTS": accNoConcat,
                       "IFSTEP": "",
                       "PREVINSTALLMENT": f"{old_installment:,.0f}",
                       "NEWINSTALLMENT": f"{installment:,.0f}",
                       "CNT_ELIGIBLE_ACC": f"{len(accNoConcat.split(","))}",
                       "ADDITIONALNOTE": ["มาตรการนี้เป็นคำแนะนำสำหรับการเปิดสินเชื่อใหม่ การพิจารณาจะเป็นไปตามระเบียบการอนุมัติสินเชื่อของธนาคาร", 
                                          "มาตรการนี้สำหรับบุคลากรขององค์กรที่มีการลงนาม MOU กับธนาคารเท่านั้น"],
                       "METAINFO": [
                                    {
                                        "METATYPE": "OLD",
                                        "DESC": f"พิจารณาข้อเสนอจาก",
                                        "PREVALUE": solutionDesc,
                                        "NEWVALUE": "",
                                    },
                                    {
                                        "METATYPE": "NEW",
                                        "DESC": f"อัตราดอกเบี้ย{occ}",
                                        "PREVALUE": "",
                                        "NEWVALUE": f"{100 * interest:,.2f}% ต่อปี",
                                    },
                                    {
                                        "METATYPE": "CHANGE",
                                        "DESC": f"ระยะเวลาผ่อนชำระ",
                                        "PREVALUE": f"{old_term:,}",
                                        "NEWVALUE": f"{term:,} งวด",
                                    },
                                    {
                                        "METATYPE": "OLD",
                                        "DESC": f"ดอกเบี้ยรวมตลอดสัญญา",
                                        "PREVALUE": f"{old_totalIntPaid:,.2f} → {totalIntPaid:,.2f} บาท",
                                        "NEWVALUE": "",
                                    }]}
    return OfferCard(**offer_card_dict)

def create_MOUoffer_cardAcc(solutionAcc: dict[str, any],
                            prev_total_int: float)-> OfferCardAcc:
    metainfo = []
    metainfo.append({"METATYPE": "NEW",
                        "DESC": "อัตราการผ่อนชำระของสินเชื่อเปิดใหม่",
                        "PREVALUE": "",
                        "NEWVALUE": f"{solutionAcc.get("installment"):,.0f} บาท"})
    
    metainfo.append({"METATYPE": "NEW",
                        "DESC": "ระยะเวลาผ่อนชำระของสินเชื่อเปิดใหม่",
                        "PREVALUE": "",
                        "NEWVALUE": f"{solutionAcc.get("term")} งวด"})
    
    metainfo.append({"METATYPE": "CHANGE",
                    "DESC": "ดอกเบี้ยรวมตลอดสัญญาเทียบกับสินเชื่อเดิม",
                    "PREVALUE": f"{prev_total_int:,.2f}",
                    "NEWVALUE": f"{solutionAcc["expIntTotal"]:,.2f} บาท"})
        
    offer_card_dict = {"ACC_NO": solutionAcc.get("refAccNo", ""),
                       "ACC_NAME": "สินเชื่อส่วนบุคคลอเนกประสงค์ภายใต้ MOU สำหรับรวมสินเชื่อ",
                       "OS": f"{solutionAcc.get("os", ""):,.2f}",
                       "INTRATE": f"{100*solutionAcc.get("intRate", ""):,.2f}",
                       "METAINFO": metainfo,
                       "ACC_NOTE": ""}
    return OfferCardAcc(**offer_card_dict)


def product_PLMOUsummary(plan: str,
                    planId: str,
                    accNoConcat: str,
                    solutionDesc: str,
                    occ: str,
                    interest: float,
                    installment: float,
                    totalIntPaid: float,
                    term: int,
                    currentStatus: dict[str, any],
                    )->DebtSolnSummary:
    
    old_installment = currentStatus["CurrentInstallment"]
    old_term = currentStatus["remainTerm"]
    old_totalIntPaid = currentStatus["expIntTotal"]
    
    description = (f"ข้อเสนอ {planId}: มาตรการรวมสินเชื่อผ่านการทำสินเชื่ออเนกประสงค์ MOU โดยไม่มีหลักประกัน \n"
                   f"ด้วยอัตราดอกเบี้ย{occ} ที่อัตรา {100*interest:,.2f} % ต่อปี\n"
                   f"โดยพิจารณายอดสินเชื่อเฉพาะบัญชี {accNoConcat} \n"
                   f"พิจารณาอัตราผ่อนชำระ{solutionDesc} โดยมีการเปลี่ยนแปลงของยอดผ่อนชำระ \n"
                   f"จาก {old_installment:,.2f} บาท/งวด ปรับเป็น {installment:,.2f} บาท/งวด \n"
                   f"โดยมีระยะเวลาผ่อนชำระหนี้เสร็จสิ้นจากเดิม  {old_term} ปรับเป็น {term} งวด \n"
                   f"ดอกเบี้ยรวมตลอดสัญญามีการเปลี่ยนแปลงจากประมาณ {old_totalIntPaid:,.2f} บาท เป็นประมาณ {totalIntPaid:,.2f} บาท \n")
    
    MOUOfferCard = create_plmou_offer_card(planId=planId,
                                            accNoConcat=accNoConcat,
                                            occ=occ,
                                            solutionDesc = solutionDesc,
                                            interest=interest,
                                            installment=installment,
                                            totalIntPaid=totalIntPaid,
                                            term=term,
                                            currentStatus=currentStatus)
    solutionAccList = [DebtSolnAcc(**{"plan": plan,
                                        "os": currentStatus["TotalOS"],
                                        "planId": planId,
                                        "refAccNo": accNoConcat,
                                        "installment": installment, #รายการผ่อนชำระงวดแรก
                                        "term": term,
                                        "intRate": interest,
                                        "expIntTotal": totalIntPaid}).model_dump()]
    
    MOUOfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_MOUoffer_cardAcc(solutionAcc = solutionAccList[0],
                                                                            prev_total_int = old_totalIntPaid))
    
    MOU_summary = DebtSolnSummary(**{"solutionDesc": solutionDesc,
                                    "plan": plan,
                                    "refAccNo": accNoConcat,
                                    "planId": planId,
                                    "planDesc": "สินเชื่อรวมหนี้ MOU แบบไม่มีหลักประกัน",
                                    "installment": installment, #รายการผ่อนชำระงวดแรก
                                    "term": term,
                                    "totalIntPaid": totalIntPaid,
                                    "constantPayment": True,
                                    "offerText": description,
                                    "offerCard": MOUOfferCard.model_dump(),
                                    "solnAcc": solutionAccList})
    return MOU_summary

def generate_PLMOU_offer(currentStatus: dict[str, any],
                         userInfo : dict[str, any],
                         dfKTBAcc: pd.DataFrame,
                         dfAccConsult: pd.DataFrame,
                         maxPayment: float,
                         maxTerm: int,
                         )-> list[DebtSolnSummary]:
    
    MOU_summary_lst = []
    totalOs = currentStatus["TotalOS"]
    accNoConcat = ",".join(sorted(list(dfAccConsult["accNo"])))
    InstallmentKTB = dfKTBAcc["installment"].sum()
    PL_MOU_interest = PL_MOU_interest_map[userInfo.get("employment_type", "")]
    PL_MOU_maxPaymentTerm = 12*np.minimum((60-userInfo.get("age", 60)), 20)

    #### Find minimal solution that the bank can offer

    planId = "PLMOU01" + dt.datetime.now().strftime("%Y%m%d%H%M%S") 
    
    minInstallment =  findInstallment(totalOS = totalOs,
                                      annual_int = PL_MOU_interest,
                                      terms = PL_MOU_maxPaymentTerm)
    totalIntPaid = findInterestPaid(Outstanding=totalOs,
                                    period_int=PL_MOU_interest/12,
                                    first_period_payment = minInstallment,
                                    payment_period = PL_MOU_maxPaymentTerm)
    
    Best_MOU_summary = product_PLMOUsummary(plan = "PLMOU01",
                                            planId=planId,
                                            accNoConcat = accNoConcat,
                                            solutionDesc = "อัตราขั้นต่ำของธนาคาร",
                                            occ = userInfo.get("employment_type"),
                                            interest = PL_MOU_interest,
                                            installment = minInstallment,
                                            term = PL_MOU_maxPaymentTerm,
                                            totalIntPaid = totalIntPaid,
                                            currentStatus = currentStatus)
    
    fg_feasibility = DSR_feasibility(ktbInstallment = InstallmentKTB,
                                    NCBInstallment = userInfo.get("InstallmentNCB_Y1"),
                                    newInstallment = minInstallment,
                                    income = userInfo.get("IncomeFromSystem"),
                                    occ = userInfo.get("employment_type"))
                    
    if fg_feasibility:
        MOU_summary_lst.append(Best_MOU_summary)

    if ((minInstallment < maxPayment) & fg_feasibility):
        if DSR_feasibility(ktbInstallment = InstallmentKTB,
                           NCBInstallment = userInfo.get("InstallmentNCB_Y1"),
                           newInstallment = maxPayment,
                           income = userInfo.get("IncomeFromSystem"),
                           occ = userInfo.get("employment_type")):
            payment = maxPayment
        else:
            payment = DSR_feasibile_payment(ktbInstallment = InstallmentKTB,
                                            NCBInstallment = userInfo.get("InstallmentNCB_Y1"),
                                            income = userInfo.get("IncomeFromSystem"),
                                            occ = userInfo.get("employment_type"))


        planId = "PLMOU02" + dt.datetime.now().strftime("%Y%m%d%H%M%S")         
        reqTerm =  findTerm(totalOS = totalOs,
                            annual_int = PL_MOU_interest,
                            monthly_payment = payment)
             
        ReqtotalIntPaid = findInterestPaid(Outstanding=totalOs,
                                        period_int=PL_MOU_interest/12,
                                        first_period_payment = payment,
                                        payment_period = reqTerm)

        Req_MOU_summary = product_PLMOUsummary(plan = "PLMOU02",
                                               planId=planId,
                                               accNoConcat = accNoConcat,
                                               solutionDesc = "ความสามารถในการชำระ",
                                               occ = userInfo.get("employment_type"),
                                               interest = PL_MOU_interest,
                                               installment = payment,
                                               term = reqTerm,
                                               totalIntPaid = ReqtotalIntPaid,
                                               currentStatus = currentStatus)
        
        MOU_summary_lst.append(Req_MOU_summary)
    
    if ((maxTerm < PL_MOU_maxPaymentTerm) & fg_feasibility):
        planId = "PLMOU03" + dt.datetime.now().strftime("%Y%m%d%H%M%S") 
    
        Installment =  findInstallment(totalOS = totalOs,
                                        annual_int = PL_MOU_interest,
                                        terms = maxTerm)
        totalIntPaid = findInterestPaid(Outstanding=totalOs,
                                        period_int=PL_MOU_interest/12,
                                        first_period_payment = Installment,
                                        payment_period = maxTerm)
        
        MOU_summary = product_PLMOUsummary(plan = "PLMOU03",
                                           planId=planId,
                                            accNoConcat = accNoConcat,
                                            solutionDesc = "ระยะเวลาในการชำระเบ็ดเสร็จ",
                                            occ = userInfo.get("employment_type"),
                                            interest = PL_MOU_interest,
                                            installment = Installment,
                                            term = maxTerm,
                                            totalIntPaid = totalIntPaid,
                                            currentStatus = currentStatus)
        
        if DSR_feasibility(ktbInstallment = InstallmentKTB,
                           NCBInstallment = userInfo.get("InstallmentNCB_Y1"),
                           newInstallment = Installment,
                           income = userInfo.get("IncomeFromSystem"),
                           occ = userInfo.get("employment_type")):
            MOU_summary_lst.append(MOU_summary)


    return MOU_summary_lst
