from app.services.functions.AmortiseCal import findInstallment, findTerm, findInterestPaid, findRemainOS
from app.services.model import DebtSolnSummary, DebtSolnAcc
from app.services.HTML.model_HTML import OfferCard, OfferCardAcc
from app.services.ai_agent.config import TDR_maxPaymentTerm, PossibleTDRLoan, TDRmin_payment_prop
import datetime as dt
import numpy as np
import pandas as pd

def summarise_first3Y_installment(df: pd.DataFrame):
    df["installment"] = df["installment"]*(df["remainTerm"]>0)
    df["installment_Y2"] = df["installment"]*(df["remainTerm"]>12)
    df["installment_Y3"] = df["installment"]*(df["remainTerm"]>24)

def current_installment_acc(dfAcc: pd.DataFrame) -> pd.Series:
    df = dfAcc.copy()
    summarise_first3Y_installment(df)
    return df[["installment", "installment_Y2", "installment_Y3"]].sum()

def cash_flow_analysis(dfAccConsult: pd.DataFrame,
                       dfKTBAcc: pd.DataFrame,
                       maxPayment: pd.DataFrame,
                       userInfo: dict[str, any]) -> pd.Series:
    df_debt_flow = pd.DataFrame()
    df_debt_flow["NCB_debt"] = pd.Series({"installment": userInfo.get("InstallmentNCB_Y1", 0),
                                          "installment_Y2": userInfo.get("InstallmentNCB_Y2", 0),
                                          "installment_Y3": userInfo.get("InstallmentNCB_Y3", 0)})
    df_debt_flow["othKTB_debt"] = current_installment_acc(dfAcc = dfKTBAcc)
    df_debt_flow["othDebt"] = df_debt_flow["NCB_debt"] + df_debt_flow["othKTB_debt"]
    df_debt_flow["noTDR_consult_debt"] = current_installment_acc(dfAcc = dfAccConsult[~dfAccConsult["fg_eligible"]])
    return pd.Series({"installment": maxPayment - df_debt_flow["noTDR_consult_debt"]["installment"],
                      "installment_Y2": maxPayment - df_debt_flow["noTDR_consult_debt"]["installment_Y2"] + (df_debt_flow["othDebt"]["installment"] - df_debt_flow["othDebt"]["installment_Y2"]),
                      "installment_Y3": maxPayment - df_debt_flow["noTDR_consult_debt"]["installment_Y3"] + (df_debt_flow["othDebt"]["installment"] - df_debt_flow["othDebt"]["installment_Y3"])})

def TDRBestFlatOffer(dfEligibleAcc: pd.DataFrame)->pd.DataFrame:
    dfBestOfferAcc = dfEligibleAcc.copy()
    dfBestOfferAcc["remainTerm"] = TDR_maxPaymentTerm
    dfBestOfferAcc["installment"] = dfBestOfferAcc.apply( lambda row: findInstallment(totalOS=row["os"],
                                                                                      annual_int=row["intRate"],
                                                                                      terms=row["remainTerm"]), axis=1)
    dfBestOfferAcc["fg_eligible"] = True
    dfBestOfferAcc["expIntTotal"] = dfBestOfferAcc.apply(lambda row: findInterestPaid(Outstanding=row["os"],
                                                                                        period_int=row["intRate"] / 12,
                                                                                        first_period_payment=row["installment"],
                                                                                        payment_period=row["remainTerm"]),  axis=1 )
    dfBestOfferAcc["installment_Y2"] = dfBestOfferAcc["installment"]
    dfBestOfferAcc["installment_Y3"] = dfBestOfferAcc["installment"]
    return dfBestOfferAcc

def TDRFlatOffer(maxPayment: pd.DataFrame,
                 dfEligibleAcc: pd.DataFrame)->pd.DataFrame:
    df = dfEligibleAcc.copy()
    df["installment"] = df["min_installment"] + (maxPayment["installment"] - df["min_installment"].sum())*(df["os"])/df["os"].sum()
    df["remainTerm"] = df.apply( lambda row: findTerm(totalOS=row["os"],
                                                      annual_int=row["intRate"],
                                                      monthly_payment=row["installment"]), axis=1)
    df["expIntTotal"] = df.apply(lambda row: findInterestPaid(Outstanding=row["os"],
                                                              period_int=row["intRate"] / 12,
                                                              first_period_payment=row["installment"],
                                                              payment_period=row["remainTerm"]),  axis=1 )
    df["installment_Y2"] = df["installment"]
    df["installment_Y3"] = df["installment"]
    return df

def TDRstepUpOffer(maxPayment: pd.Series,
                   dfEligibleAcc: pd.DataFrame)->pd.DataFrame:
    dfSTEP = dfEligibleAcc.copy()
    dfSTEP["installment"] = dfSTEP["min_installment"] + (maxPayment["installment"] - dfSTEP["min_installment"].sum())*(dfSTEP["os"])/dfSTEP["os"].sum()
    dfSTEP["term_Y1"] = np.minimum(12, dfSTEP.apply( lambda row: findTerm(totalOS=row["os"],
                                                        annual_int=row["intRate"],
                                                        monthly_payment=row["installment"]), axis=1) )
    dfSTEP["remainOS_Y1"] = np.maximum(0, dfSTEP.apply( lambda row: findRemainOS(Outstanding = row["os"],
                                                                                period_int = row["intRate"] / 12,
                                                                                first_period_payment = row["installment"],
                                                                                payment_period = row["term_Y1"]),  axis=1 ) )
    dfSTEP["expIntTotal_Y1"] = dfSTEP.apply( lambda row: findInterestPaid(Outstanding=row["os"],
                                                                        period_int=row["intRate"] / 12,
                                                                        first_period_payment=row["installment"],
                                                                        payment_period=row["term_Y1"]),  axis=1 )
    dfSTEP["min_installment_Y2"] = dfSTEP["remainOS_Y1"]*(dfSTEP["intRate"]/12)*(1/(1-TDRmin_payment_prop)) 
    dfSTEP["installment_Y2"] = dfSTEP["min_installment_Y2"] + (maxPayment["installment_Y2"] - dfSTEP["min_installment_Y2"].sum())*(dfSTEP["remainOS_Y1"])/dfSTEP["remainOS_Y1"].sum()
    dfSTEP["term_Y2"] = np.minimum(12, dfSTEP.apply( lambda row: findTerm(totalOS=row["remainOS_Y1"],
                                                        annual_int=row["intRate"],
                                                        monthly_payment=row["installment_Y2"]), axis=1) )
    dfSTEP["remainOS_Y2"] = np.maximum(0, dfSTEP.apply( lambda row: findRemainOS(Outstanding = row["remainOS_Y1"],
                                                                                period_int = row["intRate"] / 12,
                                                                                first_period_payment = row["installment_Y2"],
                                                                                payment_period = np.minimum(row["term_Y2"], 12)),  axis=1 ) )
    dfSTEP["expIntTotal_Y2"] = dfSTEP.apply( lambda row: findInterestPaid(Outstanding=row["remainOS_Y1"],
                                                                        period_int=row["intRate"] / 12,
                                                                        first_period_payment=row["installment_Y2"],
                                                                        payment_period=np.minimum(row["term_Y2"], 12) ),  axis=1 )
    dfSTEP["min_installment_Y3"] = dfSTEP["remainOS_Y2"]*(dfSTEP["intRate"]/12)*(1/(1-TDRmin_payment_prop)) 
    dfSTEP["installment_Y3"] = dfSTEP["min_installment_Y3"] + (maxPayment["installment_Y3"] - dfSTEP["min_installment_Y3"].sum())*(dfSTEP["remainOS_Y2"])/dfSTEP["remainOS_Y2"].sum()
    dfSTEP["term_Y3"] = dfSTEP.apply( lambda row: findTerm(totalOS=row["remainOS_Y2"],
                                                        annual_int=row["intRate"],
                                                        monthly_payment=row["installment_Y3"]), axis=1)
    dfSTEP["expIntTotal_Y3"] = dfSTEP.apply( lambda row: findInterestPaid(Outstanding=row["remainOS_Y2"],
                                                                        period_int=row["intRate"] / 12,
                                                                        first_period_payment=row["installment_Y3"],
                                                                        payment_period=row["term_Y3"] ),  axis=1 )
    
    dfSTEP["expIntTotal"] = dfSTEP["expIntTotal_Y1"] + dfSTEP["expIntTotal_Y2"] + dfSTEP["expIntTotal_Y3"]
    dfSTEP["remainTerm"] = dfSTEP["term_Y1"] + dfSTEP["term_Y2"] + dfSTEP["term_Y3"]
    return dfSTEP

def BalloonPlanAcc(Acc: pd.Series)->pd.Series:
    Acc["remainTerm"] = Acc["contractTerm"]
    if Acc["remainTerm"] <= 12:
        Acc["remainOS_Y1"] = findRemainOS(Outstanding = Acc["os"],
                                       period_int = Acc["intRate"] / 12,
                                       first_period_payment = Acc["installment"],
                                       payment_period = Acc["remainTerm"])
        Acc["expIntTotal"] = (Acc["installment"]*Acc["remainTerm"] + Acc["remainOS_Y1"]) - Acc["os"]
        Acc["extraPaymentlastMth"] = Acc["remainOS_Y1"]
    elif Acc["remainTerm"] <= 24:
        Acc["remainOS_Y1"] = findRemainOS(Outstanding = Acc["os"],
                                          period_int = Acc["intRate"] / 12,
                                          first_period_payment = Acc["installment"],
                                          payment_period = 12)
        Acc["remainOS_Y2"] = findRemainOS(Outstanding = Acc["remainOS_Y1"],
                                          period_int = Acc["intRate"] / 12,
                                          first_period_payment = Acc["installment_Y2"],
                                          payment_period = Acc["remainTerm"]-12)
        Acc["expIntTotal"] = (Acc["installment"]*12 + Acc["installment_Y2"]*(Acc["remainTerm"]-12)  + Acc["remainOS_Y2"]) - Acc["os"]
        Acc["extraPaymentlastMth"] = Acc["remainOS_Y2"]
    else:
        Acc["remainOS_Y1"] = findRemainOS(Outstanding = Acc["os"],
                                          period_int = Acc["intRate"] / 12,
                                          first_period_payment = Acc["installment"],
                                          payment_period = 12)
        Acc["remainOS_Y2"] = findRemainOS(Outstanding = Acc["remainOS_Y1"],
                                          period_int = Acc["intRate"] / 12,
                                          first_period_payment = Acc["installment_Y2"],
                                          payment_period = 12)
        Acc["remainOS_Y3"] = findRemainOS(Outstanding = Acc["remainOS_Y2"],
                                          period_int = Acc["intRate"] / 12,
                                          first_period_payment = Acc["installment_Y3"],
                                          payment_period = Acc["remainTerm"]-24)
        Acc["expIntTotal"] = (Acc["installment"]*12 + Acc["installment_Y2"]*12 + Acc["installment_Y3"]*(Acc["remainTerm"]-24)  + Acc["remainOS_Y3"]) - Acc["os"]
        Acc["extraPaymentlastMth"] = Acc["remainOS_Y3"]
    return Acc

def BalloonPlan(dfEligibleAcc: pd.DataFrame)->pd.DataFrame:
    dfBalloon = dfEligibleAcc.copy()
    return dfBalloon.apply(BalloonPlanAcc, axis=1)

def create_tdr_offer_card(
    planId: str,
    new_installment_3Y: pd.Series,
    old_installment_3Y: pd.Series,
    dfOffer: pd.DataFrame,
    solutionDesc: str,
    currentStatus: dict[str, any],
    fgFlat: bool,
    fgBalloon: bool) -> OfferCard:

    old_term = currentStatus["remainTerm"]
    old_totalIntPaid = currentStatus["expIntTotal"]

    plan_desc_lst = []
    Notelist = []

    if fgFlat:
        plan_desc_lst.append("ด้วยอัตราผ่อนชำระคงที่")
    else:
        plan_desc_lst.append("ด้วยอัตราผ่อนชำระแบบขั้นบันได")

    if fgBalloon:
        plan_desc_lst.append("และมีค่างวดชำระส่วนสุดท้าย")
        Notelist.append("มาตรการนี้สำหรับผู้ที่ไม่เคยมีประวัติค้างชำระกับธนาคารเท่านั้น หากเจ้าหน้าที่ตรวจพบประวัติการค้างชำระอาจมีการเสนอแนวทางมาตรการอื่น")
    elif (dfOffer["remainTerm"] <= dfOffer["contractTerm"]).all():
        plan_desc_lst.append("โดยไม่ขยายอายุสัญญา")
    else:
        plan_desc_lst.append("โดยขยายอายุสัญญา")
        Notelist.append("มาตรการนี้ส่งผลต่อข้อมูลที่ธนาคารมีการจัดส่งไปยังสำนักงานเครดิตแห่งชาติซึ่งอาจมีผลต่อการขอสินเชื่อของลูกค้าในอนาคต")

    plan_desc = "".join(plan_desc_lst)

    metainfo = [ {
                    "METATYPE": "OLD",
                    "DESC": "พิจารณาข้อเสนอจาก",
                    "PREVALUE": solutionDesc,
                    "NEWVALUE": "",
                }]
    
    if not fgFlat:
        metainfo.append({"METATYPE": "NEW",
                        "DESC": "ค่างวดผ่อนชำระในปีที่ 2 และ 3",
                        "PREVALUE": "",
                        "NEWVALUE": ( f"{new_installment_3Y["installment_Y2"]:,.0f} และ {new_installment_3Y["installment_Y3"]:,.0f} บาท/งวด"
                                     if  (np.abs(new_installment_3Y["installment_Y2"] - new_installment_3Y["installment_Y3"]) > 1)
                                     else f"{new_installment_3Y["installment_Y3"]:,.0f} บาท/งวด" ) } )

    if "โดยขยายอายุสัญญา" in plan_desc_lst:
        metainfo.append({"METATYPE": "CHANGE",
                        "DESC": "ระยะเวลาผ่อนชำระ",
                        "PREVALUE": f"{old_term} ",
                        "NEWVALUE": f"{dfOffer["remainTerm"].max()} งวด"})

     
    metainfo.append({"METATYPE": "OLD",
                    "DESC": "ดอกเบี้ยรวมตลอดสัญญา",
                    "PREVALUE": f"{old_totalIntPaid:,.2f} → {dfOffer["expIntTotal"].sum():,.2f} บาท",
                    "NEWVALUE": ""})


    BLOCK_BALLOON = []
    if fgBalloon:
        for _, acc in dfOffer[dfOffer["fg_eligible"]].iterrows():
            BLOCK_BALLOON.append({"ACC": f"{acc["accNo"]}",
                                  "TERM": f"{acc["remainTerm"]}",
                                  "PAYMENT": f"{acc["extraPaymentlastMth"]:,.2f}"})

    offer_card_dict = {
        "ICONLINK": "https://cdn-icons-png.flaticon.com/512/3135/3135706.png",
        "OFFERLINK": "PLACEHOLDER_OFFERLINK",
        "PLANID": planId,
        "OS": f"{currentStatus['TotalOS']:,.2f}",
        "PLANDESC": f"มาตรการปรับโครงสร้างหนี้{plan_desc}",
        "ACCOUNTS": f"{",".join(sorted(list(dfOffer["accNo"])))}",
        "IFSTEP": "" if fgFlat else "ปีแรก",
        "PREVINSTALLMENT": f"{old_installment_3Y["installment"]:,.0f}",
        "NEWINSTALLMENT": f"{new_installment_3Y["installment"]:,.0f}",
        "METAINFO": metainfo,
        "BOOL_NCBIMPACT": ("โดยขยายอายุสัญญา" in plan_desc_lst),
        "BLOCKHOLDER_BALLOON": BLOCK_BALLOON,
        "CNT_ELIGIBLE_ACC": str(len(dfOffer[dfOffer["fg_eligible"]])),
        "ADDITIONALNOTE": Notelist
    }

    return OfferCard(**offer_card_dict)

def create_TDRoffer_cardAcc(solutionAcc: dict[str, any],
                         originalAcc: dict[str, any],
                         fgEligible: bool,
                         fgFlat: bool,
                         fgBalloon: bool,
                         )-> OfferCardAcc:
    metainfo = []
    
    if ( (originalAcc.get("term")==solutionAcc.get("term")) | fgBalloon):
        metainfo.append({"METATYPE": "OLD",
                        "DESC": "ระยะเวลาผ่อนชำระตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc.get("term")} งวด",
                        "NEWVALUE": ""})
    else:
        metainfo.append({"METATYPE": "CHANGE",
                        "DESC": "ระยะเวลาผ่อนชำระ",
                        "PREVALUE": f"{originalAcc.get("term")}",
                        "NEWVALUE": f"{solutionAcc.get("term")} งวด"})
        
    metainfo.append({"METATYPE": "CHANGE",
                    "DESC": ("ค่างวดผ่อนชำระ" if fgFlat else "ค่างวดผ่อนชำระในปีแรก"),
                    "PREVALUE": f"{originalAcc["installment"]:,.0f}",
                    "NEWVALUE": f"{solutionAcc["installment"]:,.0f} บาท/งวด"})
    
    if not fgFlat:
        metainfo.append({"METATYPE": "NEW",
                        "DESC": "ค่างวดผ่อนชำระในปีที่ 2 และ 3",
                        "PREVALUE": "",
                        "NEWVALUE": ( f"{solutionAcc["installment_Y2"]:,.0f} และ {solutionAcc["installment_Y3"]:,.0f} บาท/งวด"
                                     if  (np.abs(solutionAcc["installment_Y2"] - solutionAcc["installment_Y3"]) > 1)
                                     else f"{solutionAcc["installment_Y3"]:,.0f} บาท/งวด" ) } )
    if fgBalloon:
         metainfo.append({"METATYPE": "NEW",
                    "DESC": "ค่างวดชำระส่วนสุดท้ายหลังสิ้นสุดสัญญา",
                    "PREVALUE": "",
                    "NEWVALUE": f"{solutionAcc["extraPaymentlastMth"]:,.2f} บาท"})
         
    if fgEligible:
        metainfo.append({"METATYPE": "CHANGE",
                        "DESC": "ดอกเบี้ยรวมตลอดสัญญา",
                        "PREVALUE": f"{originalAcc["expIntTotal"]:,.2f}",
                        "NEWVALUE": f"{solutionAcc["expIntTotal"]:,.2f} บาท"})
    else:
        metainfo.append({"METATYPE": "OLD",
                        "DESC": "ดอกเบี้ยรวมตลอดสัญญาตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc["expIntTotal"]:,.2f} บาท",
                        "NEWVALUE": ""})
    
    offer_card_dict = {"ACC_NO": solutionAcc.get("refAccNo", ""),
                       "ACC_NAME": originalAcc.get("port", ""),
                       "OS": f"{solutionAcc.get("os", ""):,.2f}",
                       "INTRATE": f"{100*solutionAcc.get("intRate", ""):,.2f}",
                       "METAINFO": metainfo,
                       "ACC_NOTE": "" if fgEligible else "บัญชีนี้ไม่เข้าเกณฑ์เข้าร่วมมาตรการ จึงคงเงื่อนไขการชำระตามเดิม"}
    return OfferCardAcc(**offer_card_dict)

def TDR_summary(plan: str,
                planId: str,
                dfOffer : pd.DataFrame,
                dfAccConsult : pd.DataFrame,
                solutionDesc : str,
                currentStatus: dict[str, any],
                fgFlat: bool,
                fgBalloon: bool,
                )->DebtSolnSummary:
    
    
    old_installment_3Y = current_installment_acc(dfAcc = dfAccConsult)
    new_installment_3Y = dfOffer[["installment", "installment_Y2", "installment_Y3"]].sum()
    old_term = currentStatus["remainTerm"]
    old_totalIntPaid = currentStatus["expIntTotal"]
    if "extraPaymentlastMth" in dfOffer.columns:
        dfOfferAcc = dfOffer[dfOffer["fg_eligible"]][["accNo", "os", "installment", "installment_Y2", "installment_Y3", "intRate","remainTerm", "expIntTotal", "extraPaymentlastMth"]].copy()
    else:
        dfOfferAcc = dfOffer[dfOffer["fg_eligible"]][["accNo", "os", "installment", "installment_Y2", "installment_Y3", "intRate","remainTerm", "expIntTotal"]].copy()
    
    dfOfferAcc.rename(columns = {"accNo": "refAccNo",
                                 "remainTerm": "term"}, inplace = True)
    dfOfferAcc["plan"] = plan
    dfOfferAcc["planId"] = planId

    planDesc_lst = []
    if fgFlat: planDesc_lst.append("ด้วยอัตราคงที่")
    else: planDesc_lst.append("ด้วยรูปแบบขั้นบันได")

    if fgBalloon: planDesc_lst.append("โดยไม่ขยายสัญญาและมีค่างวดชำระส่วนสุดท้าย")
    elif (dfOffer["remainTerm"]<=dfOffer["contractTerm"]).all(): planDesc_lst.append("โดยไม่ขยายอายุสัญญา")
    else: planDesc_lst.append("โดยขยายอายุสัญญา")
    planDesc = "".join(planDesc_lst)

    description_lst = [f"ข้อเสนอ {planId}: มาตรการปรับโครงสร้างหนี้เฉพาะสินเชื่อส่วนบุคคล (ที่ส่งผลกระทบต่อประวัติในเครดิตบูโร)\n",
                       f"เลขที่บัญชีสินเชื่อที่พิจารณา {",".join(sorted(list(dfOffer["accNo"])))} \n",
                       f"พิจารณาปรับปรุงโครงสร้างเฉพาะบัญชี {",".join(sorted(list(dfOffer[dfOffer["fg_eligible"]]["accNo"])))} \n",
                       f"กำหนดรูปแบบอัตราผ่อนชำระ{solutionDesc} {planDesc} \n"]
    description_lst.append(f"ภายหลังจากการปรับโครงสร้าง อัตราผ่อนชำระของสินเชื่อที่พิจารณาจะมีการปรับตัวจาก\n")

    if fgFlat: description_lst.append(f"{old_installment_3Y["installment"]:,.0f} บาท/งวด --> {new_installment_3Y["installment"]:,.0f} บาท/งวด\n")
    else: description_lst.append(f"ปีที่ 1: {old_installment_3Y["installment"]:,.0f} บาท/งวด --> {new_installment_3Y["installment"]:,.0f} บาท/งวด\n"
                                 f"ปีที่ 2: {old_installment_3Y["installment_Y2"]:,.0f} บาท/งวด --> {new_installment_3Y["installment_Y2"]:,.0f} บาท/งวด\n"
                                 f"ปีที่ 3: {old_installment_3Y["installment_Y3"]:,.0f} บาท/งวด --> {new_installment_3Y["installment_Y3"]:,.0f} บาท/งวด\n")

    description_lst.append(f"ดอกเบี้ยรวมทุกสินเชื่อจะปรับตัวจาก {old_totalIntPaid:,.2f} บาท เป็นประมาณ {dfOffer["expIntTotal"].sum():,.2f} บาท \n")

    if fgBalloon: 
        description_lst.append(f"โดยระยะเวลาการผ่อนชำระทุกสินเชื่อเสร็จสิ้นจะเป็นไปตามสัญญาเดิมที่ {old_term} งวด โดยมีค่างวดชำระส่วนสุดท้าย ณ สิ้นสุดสัญญา ดังนี้ \n")
        for _, acc in dfOffer[dfOffer["fg_eligible"]].iterrows():
            description_lst.append(f"- บัญชีเลขที่ {acc["accNo"]} สิ้นสุดสัญญาในงวดที่ {acc["remainTerm"]} โดยมีค่างวดชำระส่วนสุดท้ายที่ต้องชำระเพิ่มเติมจำนวน {acc["extraPaymentlastMth"]:,.2f} บาท\n")
    else: description_lst.append(f"โดยระยะเวลาการผ่อนชำระจะมีการเปลี่ยนแปลงจาก {old_term} งวด จะมีการเปลี่ยนแปลงเป็น {dfOffer["remainTerm"].max()} งวด \n")

    description = "".join(description_lst)
    TDROfferCard = create_tdr_offer_card(planId = planId,
                                         new_installment_3Y = new_installment_3Y,
                                         old_installment_3Y = old_installment_3Y,
                                         dfOffer = dfOffer,
                                         solutionDesc = solutionDesc,
                                         currentStatus = currentStatus,
                                         fgFlat = fgFlat,
                                         fgBalloon = fgBalloon)
    
    solutionAccList = [DebtSolnAcc(**offerAcc).model_dump() for offerAcc in dfOfferAcc.to_dict(orient="records")]
    dfAccConsultTmp = dfAccConsult.rename(columns = {"accNo": "refAccNo",
                                                     "remainTerm": "term"})
    originalAccList = dfAccConsultTmp.to_dict(orient="records")
    solution_lookup = {acc["refAccNo"]: acc for acc in solutionAccList}
    for ori_acc in originalAccList:
        if ori_acc["refAccNo"] in solution_lookup.keys():
            TDROfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_TDRoffer_cardAcc(solutionAcc = solution_lookup[ori_acc["refAccNo"]],
                                                                                 originalAcc = ori_acc,
                                                                                 fgEligible = True,
                                                                                 fgFlat = fgFlat,
                                                                                 fgBalloon = fgBalloon))
        else:
            TDROfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_TDRoffer_cardAcc(solutionAcc = ori_acc,
                                                                                 originalAcc = ori_acc,
                                                                                 fgEligible = False,
                                                                                 fgFlat = fgFlat,
                                                                                 fgBalloon = fgBalloon))

    TDR_summary = DebtSolnSummary(**{"solutionDesc": solutionDesc,
                                    "plan": plan,
                                    "refAccNo": ",".join(sorted(list(dfOffer["accNo"]))),
                                    "planId": planId,
                                    "planDesc": f"TDR {planDesc}",
                                    "installment": dfOffer["installment"].sum(), #รายการผ่อนชำระงวดแรก
                                    "installment_Y2": dfOffer["installment_Y2"].sum(), #รายการผ่อนชำระงวดแรก
                                    "installment_Y3": dfOffer["installment_Y3"].sum(), #รายการผ่อนชำระงวดแรก
                                    "term": dfOffer["remainTerm"].max(),
                                    "totalIntPaid": dfOffer["expIntTotal"].sum(),
                                    "constantPayment": False,
                                    "offerText": description,
                                    "offerCard": TDROfferCard.model_dump(),
                                    "solnAcc": solutionAccList})
    return TDR_summary

def NewStepOffer(planStep: str,
                 planStepBalloon: str,
                 maxPayment: pd.Series,
                 dfEligibleAcc: pd.DataFrame,
                 dfnonEligibleAcc: pd.DataFrame,
                 dfAcc: pd.DataFrame,
                 currentStatus: dict[str, any])-> list[DebtSolnSummary]:
    TDR_summary_lst = []
    dfStep = TDRstepUpOffer(maxPayment = maxPayment,
                            dfEligibleAcc = dfEligibleAcc)
    if dfStep["remainTerm"].max() <= TDR_maxPaymentTerm:
        dfTDRofferStep = pd.concat([dfStep, dfnonEligibleAcc])
        summary = TDR_summary(plan = planStep,
                              planId=planStep + dt.datetime.now().strftime("%Y%m%d%H%M%S"),
                                dfOffer = dfTDRofferStep,
                                dfAccConsult = dfAcc,
                                solutionDesc = "ตามความสามารถในการจ่ายของลูกค้า",
                                currentStatus = currentStatus,
                                fgFlat = False,
                                fgBalloon = False)
        TDR_summary_lst.append(summary)
    if (dfStep["remainTerm"] > dfStep["contractTerm"]).any():
        dfStepBalloon =  BalloonPlan(dfEligibleAcc = dfStep)
        dfTDRofferStepBalloon = pd.concat([dfStepBalloon, dfnonEligibleAcc])
        summary = TDR_summary(plan = planStepBalloon,
                            planId=planStepBalloon + dt.datetime.now().strftime("%Y%m%d%H%M%S"),
                            dfOffer = dfTDRofferStepBalloon,
                            dfAccConsult = dfAcc,
                            solutionDesc = "ตามความสามารถในการจ่ายของลูกค้า",
                            currentStatus = currentStatus,
                            fgFlat = False,
                            fgBalloon = True)
        TDR_summary_lst.append(summary)
    return TDR_summary_lst
    
    

def generate_TDR_offer(dfAccConsult: pd.DataFrame,
                       dfKTBAcc: pd.DataFrame,
                       maxPayment: pd.DataFrame,
                       userInfo: dict[str, any],
                       currentStatus: dict[str, any]) -> list[DebtSolnSummary]:
    dfAcc = dfAccConsult.copy()
    dfAcc["contractTerm"] = dfAcc["remainTerm"]
    dfAcc["min_installment"] = dfAcc["os"]*(dfAcc["intRate"]/12)*(1/(1-TDRmin_payment_prop)) 
    dfAcc["fg_eligible"] = False
    dfAcc.loc[dfAcc["port"].isin(PossibleTDRLoan), "fg_eligible"] = True
    dfnonEligibleAcc =  dfAcc[~dfAcc["fg_eligible"]].copy()
    dfnonEligibleAcc["expIntTotal"] = dfnonEligibleAcc.apply(lambda row: findInterestPaid(Outstanding=row["os"],
                                                                                           period_int=row["intRate"] / 12,
                                                                                           first_period_payment=row["installment"],
                                                                                           payment_period=row["remainTerm"]),  axis=1 )
    summarise_first3Y_installment(dfnonEligibleAcc)

    dfEligibleAcc = dfAcc[dfAcc["fg_eligible"]].copy()
    TDR_summary_lst = []
    if dfAcc["fg_eligible"].sum() > 0:
        dfBestOfferAcc = TDRBestFlatOffer(dfEligibleAcc = dfEligibleAcc)
        dfTDRoffer = pd.concat([dfBestOfferAcc, dfnonEligibleAcc])
        Best_summary = TDR_summary(plan = "TDR01",
                                   planId="TDR01" + dt.datetime.now().strftime("%Y%m%d%H%M%S"), # Flat minimum rate ,
                                   dfOffer = dfTDRoffer,
                                   dfAccConsult = dfAcc,
                                   solutionDesc = "ขั้นต่ำที่สุดตามเงื่อนไขธนาคาร",
                                   currentStatus = currentStatus,
                                   fgFlat = True,
                                   fgBalloon = False)
        TDR_summary_lst.append(Best_summary)

        #Calculate the maxPayment corresponding to the Eligible account
        maxPayment = cash_flow_analysis(dfAccConsult = dfAcc,
                                        dfKTBAcc = dfKTBAcc,
                                        maxPayment = maxPayment,
                                        userInfo = userInfo)
        
        if maxPayment["installment"] > dfEligibleAcc["min_installment"].sum():
            if maxPayment["installment"] > dfBestOfferAcc["installment"].sum():
                dfFlat =  TDRFlatOffer(maxPayment = maxPayment,
                                       dfEligibleAcc = dfEligibleAcc)
                dfTDRofferFlat = pd.concat([dfFlat, dfnonEligibleAcc])
                summary = TDR_summary(plan = "TDR02",
                                       planId="TDR02" + dt.datetime.now().strftime("%Y%m%d%H%M%S"), # Flat customer request rate ,
                                        dfOffer = dfTDRofferFlat,
                                        dfAccConsult = dfAcc,
                                        solutionDesc = "ตามความสามารถในการจ่ายของลูกค้า",
                                        currentStatus = currentStatus,
                                        fgFlat = True,
                                        fgBalloon = False)
                TDR_summary_lst.append(summary)
                FlatBalloonDesc = "ตามความสามารถในการจ่ายของลูกค้า"
            else:
                dfFlat = dfBestOfferAcc.copy()
                FlatBalloonDesc = "ตามขั้นต่ำที่สุดตามเงื่อนไขธนาคาร"

            dfFlatBalloon =  BalloonPlan(dfEligibleAcc = dfFlat)
            dfTDRofferFlatBalloon = pd.concat([dfFlatBalloon, dfnonEligibleAcc])
            summary = TDR_summary(plan="TDR03",
                                planId="TDR03" + dt.datetime.now().strftime("%Y%m%d%H%M%S"), # Flat Balloon customer request rate ,
                                dfOffer = dfTDRofferFlatBalloon,
                                dfAccConsult = dfAcc,
                                solutionDesc = FlatBalloonDesc,
                                currentStatus = currentStatus,
                                fgFlat = True,
                                fgBalloon = True)
            TDR_summary_lst.append(summary)


            TDR_summary_lst = TDR_summary_lst + NewStepOffer(planStep = "TDR04",  # Step customer request rate
                                                            planStepBalloon  = "TDR05", # Step balloon customer request rate
                                                            maxPayment = maxPayment,
                                                            dfEligibleAcc = dfEligibleAcc,
                                                            dfnonEligibleAcc = dfnonEligibleAcc,
                                                            dfAcc = dfAcc,
                                                            currentStatus = currentStatus)
            
            maxPaymentReduce = maxPayment.copy()
            maxPaymentReduce["installment_Y2"] = 0.9*maxPaymentReduce["installment_Y2"]
            maxPaymentReduce["installment_Y3"] = 0.9*maxPaymentReduce["installment_Y3"]
            TDR_summary_lst = TDR_summary_lst + NewStepOffer(planStep = "TDR06", # Reduced Step customer request rate
                                                            planStepBalloon  = "TDR07", # Reduced Step balloon customer request rate
                                                            maxPayment = maxPaymentReduce,
                                                            dfEligibleAcc = dfEligibleAcc,
                                                            dfnonEligibleAcc = dfnonEligibleAcc,
                                                            dfAcc = dfAcc,
                                                            currentStatus = currentStatus)
            
            if ( (maxPaymentReduce["installment_Y2"] > dfEligibleAcc["installment"].sum()) |
                (maxPaymentReduce["installment_Y3"] > dfEligibleAcc["installment"].sum()) ):
                maxPaymentCap = maxPaymentReduce.copy()
                maxPaymentCap["installment_Y2"] = np.minimum(maxPaymentCap["installment_Y2"], dfEligibleAcc["installment"].sum())
                maxPaymentCap["installment_Y3"] = np.minimum(maxPaymentCap["installment_Y3"], dfEligibleAcc["installment"].sum())
                TDR_summary_lst = TDR_summary_lst + NewStepOffer(planStep = "TDR08", # Reduced Step Cap customer request rate
                                                                planStepBalloon  = "TDR09", # Reduced Step Cap Balloon customer request rate
                                                                maxPayment = maxPaymentCap,
                                                                dfEligibleAcc = dfEligibleAcc,
                                                                dfnonEligibleAcc = dfnonEligibleAcc,
                                                                dfAcc = dfAcc,
                                                                currentStatus = currentStatus)
    return TDR_summary_lst



