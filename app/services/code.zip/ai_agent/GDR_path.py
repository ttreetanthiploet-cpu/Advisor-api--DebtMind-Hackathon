import pandas as pd
from app.services.functions.AmortiseCal import findInstallment, findTerm, findInterestPaid
from app.services.ai_agent.config import Min_MOB_to_GDR
from app.services.model import DebtSolnSummary, DebtSolnAcc
from app.services.HTML.model_HTML import OfferCard, OfferCardAcc
import datetime as dt

def create_gdr_offer_card(
    planId: str,
    currentStatus: dict[str, any],
    dfOffer) -> OfferCard:

    old_installment = currentStatus["CurrentInstallment"]
    old_totalIntPaid = currentStatus["expIntTotal"]

    new_installment_y1 = dfOffer["installment"].sum()
    new_installment_y2 = dfOffer["installment_Y2"].sum()
    new_total_int = dfOffer["expIntTotal"].sum()

    META_info = []
    META_info = META_info + [{  "METATYPE": "NEW",
                                "DESC": "อัตราผ่อนชำระภายหลังจาก 3 เดือน",
                                "PREVALUE": "",
                                "NEWVALUE": f"{new_installment_y2:,.2f} บาท/งวด",},
                            {  "METATYPE": "OLD",
                                "DESC": "ดอกเบี้ยรวมตลอดสัญญา",
                                "PREVALUE": f"{old_totalIntPaid:,.2f} → {new_total_int:,.2f} บาท",
                                "NEWVALUE": "",
                                }]

    offer_card_dict = {
        # -----------------------
        # HEADER
        # -----------------------
        "ICONLINK": "https://cdn-icons-png.flaticon.com/512/3135/3135706.png",
        "OFFERLINK": "PLACEHOLDER_OFFERLINK",
        "PLANID": planId,
        "PLANDESC": "มาตรการพักชำระเงินต้นระยะสั้น",
        "ACCOUNTS": ",".join(sorted(list(dfOffer["accNo"]))),
        "OS": f"{currentStatus["TotalOS"]:,.2f}",
        "IFSTEP": " 3 เดือนแรก",
        "PREVINSTALLMENT": f"{old_installment:,.0f}",
        "NEWINSTALLMENT": f"{new_installment_y1:,.0f}",
        "CNT_ELIGIBLE_ACC": f"{len(dfOffer[dfOffer["fg_eligible"]])}",
        "ADDITIONALNOTE": ["มาตรการนี้สำหรับผู้ที่ไม่เคยมีประวัติค้างชำระกับธนาคารเท่านั้น หากเจ้าหน้าที่ตรวจพบประวัติการค้างชำระอาจมีการเสนอแนวทางมาตรการอื่น"],
        # -----------------------
        # META INFO
        # -----------------------
        "METAINFO": META_info,
    }

    return OfferCard(**offer_card_dict)

def create_GDRoffer_cardAcc(solutionAcc: dict[str, any],
                         originalAcc: dict[str, any],
                         fgEligible: bool,
                         )-> OfferCardAcc:
    metainfo = []
    
    if fgEligible:
        metainfo.append({"METATYPE": "CHANGE",
                        "DESC": "ระยะเวลาผ่อนชำระ",
                        "PREVALUE": f"{originalAcc.get("term")}",
                        "NEWVALUE": f"{solutionAcc.get("term") + 3} งวด"})
    else:
        metainfo.append({"METATYPE": "OLD",
                        "DESC": "ระยะเวลาผ่อนชำระตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc.get("term")} งวด",
                        "NEWVALUE": ""})
        
        
    metainfo.append({"METATYPE": "CHANGE",
                    "DESC": ("ค่างวดผ่อนชำระจ่ายเฉพาะดอกเบี้ย 3 เดือนแรก" if fgEligible else "ค่างวดผ่อนชำระ"),
                    "PREVALUE": f"{originalAcc["installment"]:,.0f}",
                    "NEWVALUE": f"{solutionAcc["installment"]:,.0f} บาท/งวด"})
    
    if fgEligible:
        metainfo.append({"METATYPE": "NEW",
                        "DESC": "ค่างวดผ่อนชำระภายหลังจาก 3 เดือน",
                        "PREVALUE": "",
                        "NEWVALUE": f"{solutionAcc["installment"]:,.0f} บาท/งวด"} )
         
        metainfo.append({"METATYPE": "CHANGE",
                        "DESC": "ดอกเบี้ยรวมตลอดสัญญา",
                        "PREVALUE": f"{originalAcc["expIntTotal"]:,.2f}",
                        "NEWVALUE": f"{solutionAcc["expIntTotal"]:,.2f} บาท"})
    else:
        metainfo.append({"METATYPE": "OLD",
                        "DESC": "ดอกเบี้ยรวมตลอดสัญญาตามสัญญาเดิม",
                        "PREVALUE": f"{originalAcc["expIntTotal"]:,.2f} บาท",
                        "NEWVALUE": ""})
        
    offer_card_dict = {"ACC_NO": solutionAcc.get("refAccNo", ""),
                       "ACC_NAME": originalAcc.get("port", ""),
                       "OS": f"{solutionAcc.get("os", ""):,.2f}",
                       "INTRATE": f"{100*solutionAcc.get("intRate", ""):,.2f}",
                       "METAINFO": metainfo,
                       "ACC_NOTE": "" if fgEligible else "บัญชีนี้ไม่เข้าเกณฑ์เข้าร่วมมาตรการ จึงคงเงื่อนไขการชำระตามเดิม"}
    return OfferCardAcc(**offer_card_dict)

def product_GDR_summary(planId: str,
                        currentStatus: dict[str, any],
                        dfAccConsult: pd.DataFrame,
                        dfOffer : pd.DataFrame)->DebtSolnSummary:
    plan = "GDR"

    dfOfferAcc = dfOffer[dfOffer["fg_eligible"]][["accNo", "os", "installment", "installment_Y2", "intRate","remainTerm", "expIntTotal"]].copy()
    dfOfferAcc.rename(columns = {"accNo": "refAccNo",
                                 "installment": "installment",
                                 "remainTerm": "term",
                                 "intRate": "intRate"}, inplace = True)
    dfOfferAcc["plan"] = plan
    dfOfferAcc["planId"] = planId

    old_installment = currentStatus["CurrentInstallment"]
    old_totalIntPaid = currentStatus["expIntTotal"]

    
    description = (f"ข้อเสนอ {planId}: มาตรการพักชำระเงินต้นเป็นระยะเวลา 3 เดือน \n"
                   f"บัญชีที่พิจารณา: {",".join(sorted(list(dfOffer["accNo"])))} \n"
                   f"บัญชีที่สามารถพักชำระเงินต้นได้เป็นระยะเวลา 3 เดือน: {",".join(sorted(list(dfOffer[dfOffer["fg_eligible"]]["accNo"])))} \n"
                   f"โดยอัตราการผ่อนชำระรวมในช่วง 3 เดือนแรกจะปรับลดลงจาก {old_installment:,.2f} บาท/งวด เป็น {dfOffer["installment"].sum():,.2f} บาท/งวด \n"
                   f"และภายหลังจาก 3 เดือน กลับมาผ่อนชำระที่อัตรา {dfOffer["installment_Y2"].sum():,.2f} บาท/งวด \n"
                   f"ดอกเบี้ยรวมตลอดสัญญามีการเปลี่ยนแปลงจากประมาณ {old_totalIntPaid:,.2f} บาท เป็นประมาณ {dfOffer["expIntTotal"].sum():,.2f} บาท \n")
    
    GDROfferCard = create_gdr_offer_card(planId = planId,
                                         currentStatus = currentStatus,
                                         dfOffer = dfOffer)
    
    solutionAccList = [DebtSolnAcc(**offerAcc).model_dump() for offerAcc in dfOfferAcc.to_dict(orient="records")]
    dfAccConsultTmp = dfAccConsult.rename(columns = {"accNo": "refAccNo",
                                                     "remainTerm": "term"})
    originalAccList = dfAccConsultTmp.to_dict(orient="records")
    solution_lookup = {acc["refAccNo"]: acc for acc in solutionAccList}
    for ori_acc in originalAccList:
        if ori_acc["refAccNo"] in solution_lookup.keys():
            GDROfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_GDRoffer_cardAcc(solutionAcc = solution_lookup[ori_acc["refAccNo"]],
                                                                                    originalAcc = ori_acc,
                                                                                    fgEligible = True))
        else:
            GDROfferCard.BLOCKHOLDER_ACCOUNT_DETAILS.append(create_GDRoffer_cardAcc(solutionAcc = ori_acc,
                                                                                    originalAcc = ori_acc,
                                                                                    fgEligible = False))

    GDR_summary = DebtSolnSummary(**{"solutionDesc": "พักชำระเงินต้น",
                                     "plan": plan,
                                     "refAccNo": ",".join(sorted(list(dfOffer["accNo"]))),
                                     "planId": planId,
                                    "planDesc": "พักชำระเงินต้น",
                                    "installment": dfOffer["installment"].sum(), #รายการผ่อนชำระงวดแรก
                                    "term": dfOffer["installment"].max(),
                                    "totalIntPaid": dfOffer["expIntTotal"].sum(),
                                    "constantPayment": False,
                                    "offerText": description,
                                    "offerCard": GDROfferCard.model_dump(),
                                    "solnAcc": solutionAccList})
    return GDR_summary

def generate_GDR_offer(currentStatus: dict[str, any],
                       dfAccConsult: pd.DataFrame)-> list[DebtSolnSummary]:
    
    GDR_summary_lst = []
    dfAcc = dfAccConsult.copy()

    #### Find minimal solution that the bank can offer

    planId = "GDR01" + dt.datetime.now().strftime("%Y%m%d%H%M%S") 

    # Create actualTerm column

    dfAcc["cntrDate"] = pd.to_datetime(dfAcc["cntrDate"])
    dfAcc["mob"] = (pd.Timestamp.today().year - dfAcc["cntrDate"].dt.year) * 12 + (pd.Timestamp.today().month - dfAcc["cntrDate"].dt.month)

    dfAcc["fg_eligible"] = (dfAcc["mob"]>=Min_MOB_to_GDR)

    dfAcc["actualTerm"] = dfAcc.apply( lambda row: findTerm(totalOS=row["os"],
                                                            annual_int=row["intRate"],
                                                            monthly_payment=row["installment"]), axis=1)
    dfAcc["expIntTotal"] = dfAcc.apply(lambda row: findInterestPaid(Outstanding=row["os"],
                                                                    period_int=row["intRate"] / 12,
                                                                    first_period_payment=row["installment"],
                                                                    payment_period=row["actualTerm"]),  axis=1 )
    if dfAcc["fg_eligible"].sum()>0:
        dfAcc["installment_Y2"] = dfAcc["installment"]
        dfAcc.loc[dfAcc["fg_eligible"], "installment"] = (dfAcc["intRate"]/12)*dfAcc["os"]
        dfAcc.loc[dfAcc["fg_eligible"], "expIntTotal"] = 3*(dfAcc["intRate"]/12)*dfAcc["os"] + dfAcc["expIntTotal"]
        dfAcc.loc[(dfAcc["actualTerm"]<=3), "installment_Y2"] = 0
        

        GDR_summary = product_GDR_summary(planId=planId,
                                          dfAccConsult = dfAccConsult,
                                          currentStatus = currentStatus,
                                          dfOffer = dfAcc)

        GDR_summary_lst.append(GDR_summary)

    return GDR_summary_lst
